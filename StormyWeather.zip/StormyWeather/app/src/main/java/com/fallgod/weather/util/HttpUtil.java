package com.fallgod.weather.util;

import okhttp3.OkHttpClient;
import okhttp3.Request;

/**
 * Created by JackPan on 2019/10/30
 * Describe:
 */
public class HttpUtil {

    /**
     * http请求
     * @param address 请求的地址
     * @param callback 服务器返回的数据回调
     */
    public static void sendOkHttpResquest(String address,okhttp3.Callback callback){
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url(address).build();
        client.newCall(request).enqueue(callback);
    }

}
